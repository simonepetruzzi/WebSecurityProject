<div id="wsf-wrapper" class="<?php WS_Form_Common::wrapper_classes(); ?>">
<?php

	// Ajax load
	WS_Form_Common::ajax_load('https://wsform.com/plugin-support/upgrade_to_pro.php?l=#locale&v=#version&a=#action_license_item_ids');
?>
</div>
