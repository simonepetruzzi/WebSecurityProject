import Component_WS_Form from './ws-form/ws-form';

export default [Component_WS_Form];
